Directory structure
===================
project/
  upload/
    J702.liftoff(1).gff3
    private_biallelic_snps.exactly_one_line.chr1-10.vcf(4).gz
    private_biallelic_indels.all_sizes.exactly_one_line.chr1-10.vcf(5).gz
    syri.final.CG_di_tri_then_AT.no_N3.vcf(1).gz
    insertion_validation_with_cigar_with500kbfilteredvcfagainstj702(2).tsv
    deletion_validation_withcigar_for500kbfilteredvcfagainstj702(2).tsv
    B73D1.bad_500kb_bins.bed
    B73D2.bad_500kb_bins.bed
    B73D4.bad_500kb_bins.bed
    B73D7c1.bad_500kb_bins.bed
    B73D10.bad_500kb_bins.bed
  variant_enrichment/
    normalize_variants.py
    recalculate_validated.py
    recalculate_SV_bins_only.py
  gene_metaplot/
    make_metaplot_SV_bins_only.py
  gene_metaplot_SV_bins_only/
    style_metaplot_distinct.py

Requirements
============
Python 3 with numpy, pandas, matplotlib.
Run commands from project/. Keep the original input filenames shown above.

A. Current metaplot: bad bins for SVs only
========================================
python variant_enrichment/recalculate_SV_bins_only.py
python gene_metaplot/make_metaplot_SV_bins_only.py
python gene_metaplot_SV_bins_only/style_metaplot_distinct.py

Final plot: gene_metaplot_SV_bins_only/variant_metaplot_gene_start_end.png and .pdf
Solid blue SNVs, solid orange indels, solid green SVs; logarithmic y axis; gene start/end labels and 20% markers.
SNVs 17,047; small indels 3,730; validated SVs 523.
Each gene body is scaled to 100 bins; five-bin smoothing within flank/body segments. Counts normalized by actual contributing bp and class-specific genome density. All annotated gene loci included. An event can contribute to multiple overlapping gene windows.

B. Enrichment excluding bad bins ALSO for DeepVariant
=====================================================
python variant_enrichment/recalculate_validated.py

This is the earlier ALL-CLASSES bad-bin version you requested. Each line's own bad bins are subtracted from genomic category bp AND matching variant loci for SNVs, small indels, and validated SVs.
Final plot: variant_enrichment_validated/normalized_variant_distribution_validated.png and .pdf
SNVs 16,825; small indels 3,693; validated SVs 523.

Both enrichment drivers execute normalize_variants.py first (creating preliminary unmasked figures), then produce their named final outputs. Use the driver output directory, not preliminary variant_enrichment/ plots.
Both use depth ratio >=0.70 for insertion own_depth_ratio and deletion j702_depth_ratio, preserving junction pass flags and edge errors. Recalculated depth status is updated_depth_pass; original depth-pass columns are retained for auditing.

Backgrounds are full reference chr1-10, optionally subtracting supplied bad bins; not complete callable-genome masks. Variants are assigned once by SNV base, insertion left junction or deletion first deleted base.
