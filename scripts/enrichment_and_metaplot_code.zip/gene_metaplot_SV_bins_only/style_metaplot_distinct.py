from pathlib import Path
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
p=Path(__file__).resolve().parent
d=pd.read_csv(p/'metaplot_pooled_bins.tsv',sep='\t')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':12,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
fig,ax=plt.subplots(figsize=(12.5,6));colors=['#0072B2','#D55E00','#009E73'];classes=['SNVs','Indels (1–50 bp)','SVs (>50 bp)'];labels=['SNVs (17,047)','Indels, 1–50 bp (3,730)','Validated SVs, >50 bp (523)']
for cl,col,label,ls,mk in zip(classes,colors,labels,['-','-','-'],['o','s',None]):
 t=d[d.variant_class==cl].sort_values('bin');obs=t.variant_gene_overlaps.to_numpy();exp=t.expected_count.to_numpy();curve=[]
 for a,b in [(0,40),(40,140),(140,180)]:curve.extend(np.convolve(obs[a:b],np.ones(5),'same')/np.convolve(exp[a:b],np.ones(5),'same'))
 ax.plot(np.arange(180)+.5,curve,color=col,lw=2.2,label=label,linestyle=ls,marker=mk,markevery=12,markersize=3.5)
ax.axvspan(40,140,color='#f1f3f5',zorder=-5)
for x in [60,80,100,120]:ax.axvline(x,color='#d9dee3',lw=.8,ls=':',zorder=-4)
for x in [40,140]:ax.axvline(x,color='#7c8792',lw=1,ls='--',zorder=-4)
ax.axhline(1,color='#666666',lw=1,ls='--',zorder=-3)
ax.set_xlim(0,180);ax.set_yscale('log');ax.set_ylim(.2,25);ax.set_yticks([.25,.5,1,2,5,10,20],['0.25','0.5','1','2','5','10','20']);ax.set_xticks([0,40,60,80,100,120,140,180],['−2 kb','Gene start\n0%','20%','40%','60%','80%','Gene end\n100%','+2 kb']);ax.tick_params(axis='x',length=5,pad=9);ax.tick_params(axis='y',length=4);ax.set_ylabel('Relative variant density\n(fold; logarithmic scale)',labelpad=12);ax.grid(axis='y',color='#eeeeee',lw=.8);ax.set_axisbelow(True)
fig.suptitle('Private variant distribution across maize genes',fontsize=20,fontweight='bold',y=.98)
ax.set_title('Gene bodies scaled from gene start to gene end, with 2-kb flanks',fontsize=12,color='#55616d',pad=16)
ax.legend(frameon=False,loc='upper center',bbox_to_anchor=(.58,.98),fontsize=10.5)
fig.text(.5,.035,'All annotated gene loci • 100 gene-body bins • five-bin smoothing • bad-bin exclusions applied to SVs only',ha='center',fontsize=9.5,color='#55616d')
fig.subplots_adjust(left=.105,right=.985,bottom=.19,top=.83)
fig.savefig(p/'variant_metaplot_gene_start_end.png',dpi=250);fig.savefig(p/'variant_metaplot_gene_start_end.pdf');plt.close(fig)
