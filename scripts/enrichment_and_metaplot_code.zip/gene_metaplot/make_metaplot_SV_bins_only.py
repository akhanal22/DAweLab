from pathlib import Path
import collections,re,gzip,bisect
import numpy as np,pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent.parent;out=root/'gene_metaplot_SV_bins_only';out.mkdir(exist_ok=True)
v=pd.read_csv(root/'variant_enrichment_SV_bins_only'/'retained_variant_assignments.tsv',sep='\t');gprop=pd.read_csv(root/'variant_enrichment_SV_bins_only'/'retained_genome_proportions.tsv',sep='\t')
lengths={}
with gzip.open(next((root/'upload').glob('private_biallelic_snps*.gz')),'rt') as h:
 for l in h:
  m=re.match(r'##contig=<ID=(chr(?:[1-9]|10)_RagTag),length=(\d+)',l)
  if m:lengths[m[1]]=int(m[2])
  if l.startswith('#CHROM'):break
genes=set()
with open(root/'upload'/'J702.liftoff(1).gff3') as h:
 for l in h:
  if l.startswith('#'):continue
  f=l.rstrip().split('\t')
  if len(f)==9 and f[2]=='gene' and f[0] in lengths and f[6] in ['+','-']:
   genes.add((f[0],int(f[3])-1,int(f[4]),f[6],f[8].split(';')[0]))
samples=['B73D1','B73D2','B73D4','B73D7c','B73D10'];classes=['SNVs','Indels (1–50 bp)','SVs (>50 bp)'];n_bins=180
bad={}
for s in samples:
 d=collections.defaultdict(list)
 for l in (root/'upload'/f'{s.replace("B73D7c","B73D7c1")}.bad_500kb_bins.bed').read_text().splitlines():
  if not l or l.startswith(('#','track','browser')):continue
  c,a,b=l.split()[:3]
  if c in lengths:d[c].append((max(0,int(a)),min(lengths[c],int(b))))
 for c,ints in d.items():
  merged=[]
  for a,b in sorted(ints):
   if merged and a<=merged[-1][1]:merged[-1]=(merged[-1][0],max(b,merged[-1][1]))
   else:merged.append((a,b))
  starts=np.array([a for a,b in merged]);ends=np.array([b for a,b in merged]);cum=np.r_[0,np.cumsum(ends-starts)]
  bad[s,c]=(starts,ends,cum)
def excluded_before(points,s,c):
 if (s,c) not in bad:return np.zeros(len(points))
 a,b,cum=bad[s,c];i=np.searchsorted(b,points,side='right');ans=cum[i].astype(float);ok=i<len(a);ans[ok]+=np.maximum(0,points[ok]-a[i[ok]]);return ans
points={}
for s in samples:
 for cl in classes:
  for c in lengths:
   points[s,cl,c]=np.sort(v.loc[(v['sample']==s)&(v.variant_class==cl)&(v.chromosome==c),'assigned_locus_1based'].to_numpy(dtype=int)-1)
observed={cl:np.zeros(n_bins) for cl in classes};expected={cl:np.zeros(n_bins) for cl in classes};exposure={cl:np.zeros(n_bins) for cl in classes};rows=[]
for s in samples:
 exp_s=np.zeros(n_bins);exp_full=np.zeros(n_bins);counts={cl:np.zeros(n_bins) for cl in classes}
 for c,a,b,strand,gid in genes:
  if strand=='+':edges=np.r_[np.linspace(a-2000,a,41),np.linspace(a,b,101)[1:],np.linspace(b,b+2000,41)[1:]]
  else:edges=np.r_[np.linspace(b+2000,b,41),np.linspace(b,a,101)[1:],np.linspace(a,a-2000,41)[1:]]
  edges=np.rint(edges).astype(int);lo=np.clip(np.minimum(edges[:-1],edges[1:]),0,lengths[c]);hi=np.clip(np.maximum(edges[:-1],edges[1:]),0,lengths[c]);usable=(hi-lo)-(excluded_before(hi,s,c)-excluded_before(lo,s,c));assert np.all(usable>=0);exp_s+=usable;exp_full+=hi-lo
  for cl in classes:
   pts=points[s,cl,c];counts[cl]+=np.searchsorted(pts,hi)-np.searchsorted(pts,lo)
 genome_bp=gprop[gprop['sample']==s].retained_genome_bp.iloc[0]
 for cl in classes:
  n=int(((v['sample']==s)&(v.variant_class==cl)).sum());denom=genome_bp if cl=='SVs (>50 bp)' else sum(lengths.values());usable_bp=exp_s if cl=='SVs (>50 bp)' else exp_full;exposure[cl]+=usable_bp;density=n/denom;observed[cl]+=counts[cl];expected[cl]+=usable_bp*density
  for i in range(n_bins):rows.append(dict(sample=s,variant_class=cl,bin=i,variant_gene_overlaps=int(counts[cl][i]),retained_gene_bin_bp=int(usable_bp[i]),expected_count=usable_bp[i]*density))
pd.DataFrame(rows).to_csv(out/'metaplot_by_line_bins.tsv',sep='\t',index=False)
rows=[]
for cl in classes:
 for i in range(n_bins):rows.append(dict(variant_class=cl,bin=i,variant_gene_overlaps=int(observed[cl][i]),retained_gene_bin_bp=int(exposure[cl][i]),expected_count=expected[cl][i],fold_enrichment=observed[cl][i]/expected[cl][i] if expected[cl][i]>0 else np.nan))
pd.DataFrame(rows).to_csv(out/'metaplot_pooled_bins.tsv',sep='\t',index=False)
# Smooth observed and expected counts separately within each region; do not mix flanks and body.
def smooth_ratio(obs,exp):
 result=[]
 for lo,hi in [(0,40),(40,140),(140,180)]:
  kernel=np.ones(5);result.extend(np.convolve(obs[lo:hi],kernel,'same')/np.convolve(exp[lo:hi],kernel,'same'))
 return np.array(result)
plt.rcParams.update({'font.size':12,'axes.spines.top':False,'axes.spines.right':False,'savefig.facecolor':'white'})
fig,ax=plt.subplots(figsize=(11,5.5));colors=['#0072B2','#D55E00','#009E73'];x=np.arange(180)+.5
for cl,col in zip(classes,colors):
 n=int((v.variant_class==cl).sum());ax.plot(x,smooth_ratio(observed[cl],expected[cl]),color=col,lw=2,label=f'{cl}: n = {n:,}')
ax.axvspan(40,140,color='#eeeeee',alpha=.65,zorder=-2);ax.axvline(40,color='gray',ls=':',lw=1);ax.axvline(140,color='gray',ls=':',lw=1);ax.axhline(1,color='black',ls='--',lw=1);ax.set_xlim(0,180);ax.set_xticks([0,40,90,140,180],['−2 kb','TSS','Gene body','TES','+2 kb']);ax.set_ylabel('Variant density / genome-wide density');ax.set_title('Private variants across length-normalized maize genes',fontweight='bold');ax.legend(frameon=False,fontsize=10);ax.set_ylim(bottom=0);fig.text(.5,.015,'Gene bodies scaled to 100 bins • counts normalized by bp per bin • bad bins excluded for SVs only',ha='center',fontsize=9);fig.tight_layout(rect=[0,.05,1,1]);fig.savefig(out/'SNV_indel_validated_SV_metaplot.png',dpi=250);fig.savefig(out/'SNV_indel_validated_SV_metaplot.pdf');plt.close(fig)
(out/'METHODS.txt').write_text(f'Genes: {len(genes):,} exact-deduplicated gene loci on reference chr1–10; all genes, not only genes with variants. Gene bodies scaled to 100 bins, upstream/downstream 2 kb each split into 40 bins (50 bp), oriented by strand. Gene boundaries are used as annotated TSS/TES proxies. Each line uses its own bad-bin mask and retained variants from the validated enrichment analysis. Exposure is retained reference bp summed over gene-bin instances. Overlapping gene windows can count a variant multiple times, once per gene; totals in legend are unique input events across lines, not plotted overlaps. SVs are point/junction loci, not full affected spans. Expected per-bin count = sum over lines (retained bin bp × class-specific variant count / retained chromosome 1–10 bp). Curves use a five-bin moving ratio of summed observed to summed expected counts separately within each flank/body region. Thus smoothing is 250 bp in flanks and 5% of scaled body. Baseline 1 = class-specific genome-wide density. No confidence intervals or significance testing. No complete callable mask beyond supplied bad bins.\n')
print('Genes',len(genes));print('Input counts',v.variant_class.value_counts().to_dict());print('Maximum smoothed fold',{cl:float(np.max(smooth_ratio(observed[cl],expected[cl]))) for cl in classes})
